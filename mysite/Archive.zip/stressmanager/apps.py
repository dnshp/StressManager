from django.apps import AppConfig


class StressmanagerConfig(AppConfig):
    name = 'stressmanager'
